Swagger 文件
> http://localhost:8080/api-docs

Swagger Ui
> http://localhost:8080/swagger-ui/index.html

H2 Database
> http://localhost:8080/h2-console
> 
> JDBC URL: jdbc:h2:mem:testdb
>
> User Name: sa
>
> Password: 留空即可

版本
> Spring Boot 3

使用依賴
> Spring Web
> 
> Spring Data Jpa
> 
> H2 Database
> 
> Swagger Openapi
