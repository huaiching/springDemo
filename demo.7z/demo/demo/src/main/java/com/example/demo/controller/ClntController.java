package com.example.demo.controller;

import com.example.demo.entity.Clnt;
import com.example.demo.repository.ClntRepositroy;
import com.example.demo.service.ClntService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Tag(name = "客戶資料檔", description = "客戶資料檔 API 接口")
@RestController
@RequestMapping("/clnt")
public class ClntController {
    @Autowired
    private ClntService clntService;
    @Autowired
    private ClntRepositroy clntRepositroy;

    @Operation(summary = "保存資料 (單筆)", description = "無ID=新增 / 有ID=更新")
    @PostMapping("/save")
    public Clnt save(@RequestBody Clnt clnt) {
        return clntService.save(clnt);
    }

    @Operation(summary = "保存資料資料 (多筆)", description = "無ID=新增 / 有ID=更新")
    @PostMapping("/saveAll")
    public List<Clnt> saveAll(@RequestBody List<Clnt> clntList) {
        return clntService.saveAll(clntList);
    }

    @Operation(summary = "查詢資料: 根據 主鍵(clientId) ", description = "查詢單筆資料")
    @GetMapping("/findById")
    public Optional<Clnt> findById(@RequestParam String clientId) {
        return clntService.findById(clientId);
    }

    @Operation(summary = "查詢資料: 根據 主鍵集合(clientId) ", description = "查詢多筆資料")
    @PostMapping("/findAllById")
    public List<Clnt> findAllById(@RequestBody List<String> clientIdList) {
        return clntService.findAllById(clientIdList);
    }

    @Operation(summary = "刪除資料: 根據 主鍵(clientId) ", description = "刪除單筆資料")
    @DeleteMapping("/deleteById")
    public void deleteById(@RequestParam String clientId) {
        clntService.deleteById(clientId);
    }

    @Operation(summary = "刪除資料: 根據 主鍵集合(clientId) ", description = "刪除多筆資料")
    @DeleteMapping("/deleteAllById")
    public void deleteAllById(@RequestBody List<String> clientIdList) {
        clntService.deleteAllById(clientIdList);
    }

    @Operation(summary = "查詢資料: 根據 姓名 ", description = "查詢多筆資料")
    @GetMapping("/findByNames")
    public List<Clnt> findByNames(@RequestParam String names) {
        return clntRepositroy.findByNames(names);
    }
}
