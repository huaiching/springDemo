package com.example.demo.service.Impl;

import com.example.demo.dto.AddrDto;
import com.example.demo.entity.Addr;
import com.example.demo.mapper.AddrMapper;
import com.example.demo.repository.AddrRepositroy;
import com.example.demo.service.AddrService;
import jakarta.persistence.EntityManager;
import org.hibernate.query.NativeQuery;
import org.hibernate.transform.Transformers;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class AddrServiceImpl implements AddrService {
    @Autowired
    AddrRepositroy addrRepositroy;
    @Autowired
    AddrMapper addrMapper;
    @Autowired
    EntityManager entityManager;

    /**
     * 新增/修改 資料 (單筆)
     *
     * @param addrDto
     * @return
     */
    @Transactional
    public Addr save(AddrDto addrDto) {
        Addr addr = new Addr();
        BeanUtils.copyProperties(addrDto, addr);
        addr.setAddrKey(new Addr.AddrKey(addrDto.getClientId(), addrDto.getAddrInd()));
        return addrRepositroy.save(addr);
    }

    /**
     * 新增/修改 資料 (多筆)
     *
     * @param addrDtoList
     * @return
     */
    @Transactional
    public List<Addr> saveAll(List<AddrDto> addrDtoList) {
        List<Addr> addrList = new ArrayList<>();
        addrDtoList.forEach(addrDto -> {
            Addr addr = new Addr();
            BeanUtils.copyProperties(addrDto, addr);
            addr.setAddrKey(new Addr.AddrKey(addrDto.getClientId(), addrDto.getAddrInd()));
            addrList.add(addr);
        });
        return addrRepositroy.saveAll(addrList);
    }

    /**
     * 根據 主鍵(clientId) 查詢資料
     *
     * @param addrKey clientId + addrInd
     * @return
     */
    @Override
    public AddrDto findById(Addr.AddrKey addrKey) {
        Addr addr = addrRepositroy.findById(addrKey).get();
        return addrMapper.toAddrDto(addr);
    }

    /**
     * 根據 主鍵集合(clientId) 查詢資料
     *
     * @param addrKeyList clientId + addrInd 集合
     * @return
     */
    @Override
    public List<AddrDto> findAllById(List<Addr.AddrKey> addrKeyList) {
        List<Addr> addrList = addrRepositroy.findAllById(addrKeyList);
        return addrMapper.toAddrDtoList(addrList);
    }

    /**
     * 根據 主鍵(clientId) 刪除 資料
     *
     * @param addrKey clientId + addrInd
     */
    @Transactional
    public void deleteById(Addr.AddrKey addrKey) {
        addrRepositroy.deleteById(addrKey);

    }

    /**
     * 根據 主鍵集合(clientId) 刪除 資料
     *
     * @param addrKeyList clientId + addrInd 集合
     */
    @Transactional
    public void deleteAllById(List<Addr.AddrKey> addrKeyList) {
        addrRepositroy.deleteAllById(addrKeyList);
    }

    /**
     * 根據 客戶證號 查詢資料
     *
     * @param clientId
     * @return
     */
    @Override
    public List<AddrDto> findByClientId(String clientId) {
        String sql = "SELECT * FROM addr " +
                "WHERE client_id = :clientId " +
                "ORDER BY addr_ind ";
        List<Addr> addrList = entityManager.createNativeQuery(sql, Addr.class)
                .unwrap(NativeQuery.class)
                .setParameter("clientId", clientId)
                .getResultList();

        return addrMapper.toAddrDtoList(addrList);
    }

    /**
     * 取得 E指示
     *
     * @param clientId
     * @return
     */
    @Override
    public AddrDto findEAddrByClientId(String clientId) {
        String sql = "SELECT * FROM addr " +
                "WHERE client_id = :clientId " +
                "  AND addr_ind = 'E' ";
        List<Addr> addrList = entityManager.createNativeQuery(sql, Addr.class)
                .unwrap(NativeQuery.class)
                .setParameter("clientId", clientId)
                .getResultList();
        if (CollectionUtils.isEmpty(addrList)) {
            return new AddrDto();
        } else  {
            return addrMapper.toAddrDtoList(addrList).get(0);
        }
    }
}
