package com.example.demo.dto;


import com.example.demo.entity.Addr;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;

import java.io.Serializable;
import java.util.Objects;

public class AddrDto {
    @Schema(description = "客戶證號")
    private String clientId;

    @Schema(description = "地址指示")
    private String addrInd;

    @Schema(description = "地址")
    private String address;

    @Schema(description = "電話")
    private String tel1;

    // Getters 和 Setters
    public String getClientId() {
        return clientId;
    }
    public void setClientId(String clientId) {
        this.clientId = clientId;
    }
    public String getAddrInd() {
        return addrInd;
    }
    public void setAddrInd(String addrInd) {
        this.addrInd = addrInd;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public String getTel1() {
        return tel1;
    }
    public void setTel1(String tel1) {
        this.tel1 = tel1;
    }

    // 取得主鍵
    @Schema(hidden = true) // Swagger 隐藏
    @JsonIgnore // Jackson 忽略
    public Addr.AddrKey getAddrKey() {
        return new Addr.AddrKey(clientId, addrInd);
    }
}


