package com.example.demo.service.Impl;

import com.example.demo.service.EntityModifyServive;
import com.example.demo.util.EntitySqlUtil;
import jakarta.persistence.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;


@Service
public class EntityModifyServiceImpl implements EntityModifyServive {

    @PersistenceContext
    private EntityManager entityManager;

    /**
     * 根據 JPA 的 @Column(name) 自動生成 INSERT SQL 並執行
     * @param entityInstance    資料表的 實體
     */
    @Transactional
    public void insertEntity(Object entityInstance) {
        // 取得 tableName
        String entityName = EntitySqlUtil.getTableName(entityInstance.getClass());

        // 取得 entity 欄位與數值
        Map<String, Object> entityMap = EntitySqlUtil.getNameAndValues(entityInstance);

        // 動態生成 SQL
        // (1) 組合 前置SQL
        StringBuilder sql = new StringBuilder("INSERT INTO ")
                .append(entityName).append(" (");
        StringBuilder sqlValue = new StringBuilder("VALUES (");
        // (2) 遍歷 entity 欄位與數值 設定SQL
        for (Map.Entry<String, Object> entity : entityMap.entrySet()) {
            if (entity.getValue() != null) {
                String columnName = entity.getKey();
                sql.append(columnName).append(",");
                sqlValue.append(":").append(columnName).append(",");
            }
        }
        // (3) 動態SQL 刪除結尾 ","
        sql.setLength(sql.length()-1);
        sqlValue.setLength(sqlValue.length()-1);
        // (4) 組合結尾
        sql.append(") ").append(sqlValue).append(")");

        // 執行 SQL
        Query execute = entityManager.createNativeQuery(sql.toString());
        for (Map.Entry<String, Object> entity : entityMap.entrySet()) {
            if (entity.getValue() != null) {
                execute.setParameter(entity.getKey(), entity.getValue());
            }
        }
        execute.executeUpdate();
    }

    /**
     * 根據 JPA 的 @Column(name) 自動生成 UPDATE SQL 並執行
     * @param oldEntityInstance 資料表的 舊實體
     * @param newEntityInstance 資料表的 新實體
     */
    @Transactional
    public void updateEntity(Object oldEntityInstance, Object newEntityInstance) {
        if (!oldEntityInstance.getClass().equals(newEntityInstance.getClass())) {
            throw new RuntimeException("舊實體和新實體必須是相同類型");
        }

        // 取得 tableName
        String entityName = EntitySqlUtil.getTableName(oldEntityInstance.getClass());

        // 取得 entity 欄位與數值
        Map<String, Object> oldEntityMap = EntitySqlUtil.getNameAndValues(oldEntityInstance);
        Map<String, Object> newEntityMap = EntitySqlUtil.getNameAndValues(newEntityInstance);

        // 動態生成 SQL
        // (1) 組合 SET
        StringBuilder sql = new StringBuilder("UPDATE ")
                .append(entityName).append(" SET ");
        for (Map.Entry<String, Object> entity : newEntityMap.entrySet()) {
            sql.append(entity.getKey()).append("=:new_").append(entity.getKey()).append(",");
        }
        sql.setLength(sql.length()-1);

        // (2) 組合 WHERE
        StringBuilder sqlWhere = new StringBuilder("WHERE ");
        for (Map.Entry<String, Object> entity : oldEntityMap.entrySet()) {
            sqlWhere.append(entity.getKey()).append("=:old_").append(entity.getKey()).append(" AND ");
        }
        sqlWhere.setLength(sqlWhere.length()-4);

        // (3) 組合結尾
        sql.append(" ").append(sqlWhere);

        // 執行 SQL
        Query execute = entityManager.createNativeQuery(sql.toString());
        for (Map.Entry<String, Object> entity : newEntityMap.entrySet()) {
            String entityKey = "new_" + entity.getKey();
            execute.setParameter(entityKey, entity.getValue());
        }
        for (Map.Entry<String, Object> entity : oldEntityMap.entrySet()) {
            String entityKey = "old_" + entity.getKey();
            execute.setParameter(entityKey, entity.getValue());
        }
        sqlWhere.setLength(sqlWhere.length()-4);
        execute.executeUpdate();
    }

    /**
     * 根據 JPA 的 @Column(name) 自動生成 DELETE SQL 並執行
     * @param entityInstance 資料表的 實體
     */
    @Transactional
    public void deleteEntity(Object entityInstance) {
        // 取得 tableName
        String entityName = EntitySqlUtil.getTableName(entityInstance.getClass());

        // 取得 entity 欄位與數值
        Map<String, Object> entityMap = EntitySqlUtil.getNameAndValues(entityInstance);

        // 動態生成 SQL
        // (1) 組合 SQL
        StringBuilder sql = new StringBuilder("DELETE FROM ")
                .append(entityName).append(" WHERE ");
        for (Map.Entry<String, Object> entity : entityMap.entrySet()) {
            sql.append(entity.getKey()).append("=:").append(entity.getKey()).append(" AND ");
        }
        // (2) 動態SQL 刪除結尾 ","
        sql.setLength(sql.length()-4);;

        // 執行 SQL
        Query execute = entityManager.createNativeQuery(sql.toString());
        for (Map.Entry<String, Object> entity : entityMap.entrySet()) {
            if (entity.getValue() != null) {
                execute.setParameter(entity.getKey(), entity.getValue());
            }
        }
        execute.executeUpdate();
    }

}



