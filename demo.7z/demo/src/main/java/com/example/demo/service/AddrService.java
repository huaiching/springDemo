package com.example.demo.service;

import com.example.demo.dto.AddrDto;
import com.example.demo.entity.Addr;
import com.example.demo.entity.Clnt;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface AddrService {

    /**
     * 新增/修改 資料 (單筆)
     * @param addrDto
     * @return
     */
    Addr save(AddrDto addrDto);

    /**
     * 新增/修改 資料 (多筆)
     * @param addrDtoList
     * @return
     */
    List<Addr> saveAll(List<AddrDto> addrDtoList);

    /**
     * 根據 主鍵(clientId) 查詢資料
     * @param addrKey clientId + addrInd
     * @return
     */
    AddrDto findById(Addr.AddrKey addrKey);

    /**
     * 根據 主鍵集合(clientId) 查詢資料
     * @param addrKeyList clientId + addrInd 集合
     * @return
     */
    List<AddrDto> findAllById(List<Addr.AddrKey> addrKeyList);

    /**
     * 根據 主鍵(clientId) 刪除 資料
     * @param addrKey clientId + addrInd
     */
    void deleteById(Addr.AddrKey addrKey);

    /**
     * 根據 主鍵集合(clientId) 刪除 資料
     * @param addrKeyList clientId + addrInd 集合
     */
    void deleteAllById(List<Addr.AddrKey> addrKeyList);

    /**
     * 根據 客戶證號 查詢資料
     * @param clientId
     * @return
     */
    List<AddrDto> findByClientId(String clientId);

    /**
     * 取得 E指示
     * @param clientId
     * @return
     */
    AddrDto findEAddrByClientId(String clientId);
}
