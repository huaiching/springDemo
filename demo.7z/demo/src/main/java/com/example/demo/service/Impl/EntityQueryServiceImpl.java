package com.example.demo.service.Impl;

import com.example.demo.dto.EntityWhereDto;
import com.example.demo.entity.Benf;
import com.example.demo.service.EntityQueryService;
import com.example.demo.util.EntitySqlUtil;
import io.micrometer.common.util.StringUtils;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;
import jakarta.persistence.Tuple;
import org.hibernate.query.NativeQuery;
import org.hibernate.transform.ResultTransformer;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Service;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

@Service
public class EntityQueryServiceImpl implements EntityQueryService {
    @PersistenceContext
    private EntityManager entityManager;

    /**
     * 根據 JPA 的 @Table(name) 自動生成 SELECT SQL 並執行
     * 查詢條件 限定為 AND
     * @param tableClass 要查詢的 table Class
     * @param whereList 查詢條件
     * @return
     * @param <T>
     */
    public <T> List<T> selectEntity(Class<T> tableClass, List<EntityWhereDto> whereList) {
        return selectEntity(tableClass, whereList, null);
    }

    /**
     * 根據 JPA 的 @Table(name) 自動生成 SELECT SQL 並執行
     * 查詢條件 限定為 AND
     * @param tableClass 要查詢的 table Class
     * @param whereList 查詢條件
     * @param otherSql 其他SQL語句
     * @return
     * @param <T>
     */
    public <T> List<T> selectEntity(Class<T> tableClass, List<EntityWhereDto> whereList, String otherSql) {
        // 取得 tableName
        String entityName = EntitySqlUtil.getTableName(tableClass);

        // 動態生成 SQL
        // (1) 設定 查詢所有欄位
//        StringBuilder sql = new StringBuilder("SELECT * FROM ").append(entityName).append(" WHERE 1=1 ");
        StringBuilder sql = new StringBuilder("SELECT ");
        for (Field field : tableClass.getDeclaredFields()) {
            String columnName = EntitySqlUtil.getColumnName(field);
            String attributeName = field.getName();
            sql.append(columnName).append(" AS ").append(attributeName).append(",");
        }
        sql.setLength(sql.length()-1);
        sql.append(" FROM ").append(entityName).append(" WHERE 1=1 ");
        // (2) 設定 查詢條件
        for (EntityWhereDto where : whereList) {
            sql.append("AND ");
            sql.append(where.getColumnName()).append(" ")
                    .append(where.getOperator()).append(" :").append(where.getColumnName());
        }
        // (3) 設定 其他SQL語句
        if (!StringUtils.isEmpty(otherSql)) {
            sql.append(" ").append(otherSql);
        }
        System.err.println(sql.toString());
        
        // 執行 SQL
        NativeQuery query = entityManager.createNativeQuery(sql.toString())
                .unwrap(NativeQuery.class);
        for (EntityWhereDto where : whereList) {
            query.setParameter(where.getColumnName(), where.getValue());
        }
        
        return query.getResultList();
    }
}
