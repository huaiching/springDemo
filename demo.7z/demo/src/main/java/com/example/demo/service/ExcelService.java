package com.example.demo.service;

public interface ExcelService {
    /**
     * 產出 客戶地址明細表
     * @param clientId
     * @return
     */
    byte[] exportDemo02(String clientId);
}
