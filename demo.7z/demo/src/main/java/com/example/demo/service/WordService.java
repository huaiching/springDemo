package com.example.demo.service;

public interface WordService {
    /**
     * 產出 客戶資料明細表
     * @param clientId
     * @return
     */
    byte[] exportDemo01(String clientId);
}
