package com.example.demo.mapper;

import com.example.demo.entity.Addr;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class AddrMapper {
//    public AddrDto toAddrDto(Addr addr){
//        AddrDto addrDto = new AddrDto();
//        BeanUtils.copyProperties(addr, addrDto);
//        return addrDto;
//    }
//
//    public List<AddrDto> toAddrDtoList(List<Addr> addrList){
//        List<AddrDto> addrDtoList = new ArrayList<>();
//        addrList.forEach(addr -> {
//            addrDtoList.add(toAddrDto(addr));
//        });
//        return addrDtoList;
//    }
}

