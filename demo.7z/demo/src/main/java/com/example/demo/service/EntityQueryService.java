package com.example.demo.service;

import com.example.demo.dto.EntityWhereDto;

import java.util.List;

public interface EntityQueryService {
    /**
     * 根據 JPA 的 @Table(name) 自動生成 SELECT SQL 並執行
     * 查詢條件 限定為 AND
     * @param tableClass 要查詢的 table Class
     * @param whereList 查詢條件
     * @return
     * @param <T>
     */
    <T> List<T> selectEntity(Class<T> tableClass, List<EntityWhereDto> whereList);
}
