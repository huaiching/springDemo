package com.example.demo.util;

import jakarta.persistence.Column;
import jakarta.persistence.Table;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

public class EntitySqlUtil {
    /**
     * 根據 JPA 的 @Column(name) 獲取 資料表實例 的 欄位及數值
     * @param entity    資料表的 實例
     * @return  Map: key=entityName, value=entityValue
     */
    public static Map<String, Object> getNameAndColumnName(Object entity) {
        Map<String, Object> entityData = new HashMap<>();

        // 取得 entity 實體 所有欄位的 Field
        Field[] fields = entity.getClass().getDeclaredFields();
        for (Field field : fields) {
            entityData.put(field.getName(), getColumnName(field));
        }
        return entityData;
    }
    /**
     * 根據 JPA 的 @Column(name) 獲取 資料表實例 的 欄位及數值
     * @param entity    資料表的 實例
     * @return  Map: key=entityName, value=entityValue
     */
    public static Map<String, Object> getNameAndValues(Object entity) {
        Map<String, Object> entityData = new HashMap<>();

        // 取得 entity 實體 所有欄位的 Field
        Field[] fields = entity.getClass().getDeclaredFields();
        for (Field field : fields) {
            // 獲取 columnName
            String columnName = getColumnName(field);
            // 獲取 columnValue
            field.setAccessible(true);
            try {
                Object columnValue = field.get(entity);
                entityData.put(columnName, columnValue);
            } catch (IllegalAccessException e) {
                throw new RuntimeException("Failed to access field value");
            }
        }
        return entityData;
    }
    /**
     * 根據 entity 的 @Table(name) 獲取 tableName
     * @param entityClass   資料表的 類對象
     * @return tableName
     */
    public static String getTableName(Class<?> entityClass) {
        // 取得 @Table 的資料
        Table tableAnnotation = entityClass.getAnnotation(Table.class);
        // 有 @Table(name) 才取得 tableName，否則 取得 className
        if (tableAnnotation != null && !tableAnnotation.name().isEmpty()) {
            return tableAnnotation.name();
        } else {
            return entityClass.getName();
        }
    }

    /**
     * 根據 entity 的 @Column(name) 獲取 columnName
     * @param field entity 欄位 透過反射獲取的 Field 物件
     * @return columnName
     */
    public static String getColumnName(Field field) {
        // 取得 @Column 的資料
        Column columnAnnotation = field.getAnnotation(Column.class);
        // 有 @Column(name) 才取得 columnName，否則 取得 欄位名稱
        if (columnAnnotation != null) {
            return columnAnnotation.name();
        } else {
            return field.getName();
        }
    }
}
