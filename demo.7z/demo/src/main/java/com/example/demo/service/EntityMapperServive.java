package com.example.demo.service;

import org.springframework.transaction.annotation.Transactional;

import java.util.Map;

public interface EntityMapperServive {

    /**ager entityManager;

     /**
     * 根據 JPA 的 @Column(name) 自動生成 INSERT SQL 並執行
     * @param entityInstance    資料表的 實體
     */
    void insertEntity(Object entityInstance);

    /**
     * 根據 JPA 的 @Column(name) 自動生成 UPDATE SQL 並執行
     * @param oldEntityInstance 資料表的 舊實體
     * @param newEntityInstance 資料表的 新實體
     */
    void updateEntity(Object oldEntityInstance, Object newEntityInstance);

    /**
     * 根據 JPA 的 @Column(name) 自動生成 DELETE SQL 並執行
     * @param entityInstance 資料表的 實體
     */
    @Transactional
    void deleteEntity(Object entityInstance);

}
