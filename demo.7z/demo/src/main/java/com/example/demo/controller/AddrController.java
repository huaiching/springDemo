package com.example.demo.controller;

import com.example.demo.dto.AddrDto;
import com.example.demo.entity.Addr;
import com.example.demo.entity.Clnt;
import com.example.demo.repository.AddrRepositroy;
import com.example.demo.service.AddrService;
import com.example.demo.service.ClntService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Tag(name = "客戶地址檔", description = "客戶地址檔 API 接口")
@RestController
@RequestMapping("/addr")
public class AddrController {
    @Autowired
    private AddrService addrService;

    @Operation(summary = "保存資料 (單筆)", description = "無ID=新增 / 有ID=更新")
    @PostMapping("/save")
    public ResponseEntity<Addr> save(@RequestBody AddrDto addrDto) {
        return ResponseEntity.ok(addrService.save(addrDto));
    }

    @Operation(summary = "保存資料資料 (多筆)", description = "無ID=新增 / 有ID=更新")
    @PostMapping("/saveAll")
    public ResponseEntity<List<Addr>> saveAll(@RequestBody List<AddrDto> addrDtoList) {
        return ResponseEntity.ok(addrService.saveAll(addrDtoList));
    }

    @Operation(summary = "查詢資料: 根據 主鍵(clientId + addrInd) ", description = "查詢單筆資料")
    @PostMapping("/findById")
    public ResponseEntity<AddrDto> findById(@RequestBody Addr.AddrKey addrKey) {
        return ResponseEntity.ok(addrService.findById(addrKey));
    }

    @Operation(summary = "查詢資料: 根據 主鍵集合(clientId + addrInd) ", description = "查詢多筆資料")
    @PostMapping("/findAllById")
    public ResponseEntity<List<AddrDto>> findAllById(@RequestBody List<Addr.AddrKey> addrKeyList) {
        return ResponseEntity.ok(addrService.findAllById(addrKeyList));
    }

    @Operation(summary = "刪除資料: 根據 主鍵(clientId + addrInd) ", description = "刪除單筆資料")
    @DeleteMapping("/deleteById")
    public ResponseEntity<Void> deleteById(@RequestBody Addr.AddrKey addrKey) {
        addrService.deleteById(addrKey);
        return ResponseEntity.ok().build();
    }

    @Operation(summary = "刪除資料: 根據 主鍵集合(clientId + addrInd) ", description = "刪除多筆資料")
    @DeleteMapping("/deleteAllById")
    public ResponseEntity<Void> deleteAllById(@RequestBody List<Addr.AddrKey> addrKeyList) {
        addrService.deleteAllById(addrKeyList);
        return ResponseEntity.ok().build();
    }

    @Operation(summary = "查詢資料: 根據 客戶證號 ", description = "查詢單筆資料")
    @GetMapping("/findByClientId")
    public ResponseEntity<List<AddrDto>> findByClientId(@RequestParam("clientId") String clientId){
        return ResponseEntity.ok(addrService.findByClientId(clientId));
    }

    @Operation(summary = "查詢資料: 取得 E指示 ", description = "取得 E指示")
    @GetMapping("/findEAddrByClientId")
    public ResponseEntity<AddrDto> findEAddrByClientId(@RequestParam("clientId") String clientId) {
        return ResponseEntity.ok(addrService.findEAddrByClientId(clientId));
    }
}
