package com.example.demo.service.Impl;

import com.example.demo.service.EntityMapperServive;
import jakarta.persistence.Column;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Table;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;


@Service
public class EntityMapperServiceImpl implements EntityMapperServive {

    @PersistenceContext
    private EntityManager entityManager;

    /**
     * 根據 JPA 的 @Column(name) 自動生成 INSERT SQL 並執行
     * @param entityInstance    資料表的 實體
     */
    @Transactional
    public void insertEntity(Object entityInstance) {
        // 取得 tableName
        String entityName = getTableName(entityInstance.getClass());

        // 取得 entity 欄位與數值
        Map<String, Object> entityMap = getEntityNameAndValues(entityInstance);

        // 動態生成 SQL
        // (1) 組合 前置SQL
        StringBuilder sql = new StringBuilder("INSERT INTO ")
                .append(entityName).append(" (");
        StringBuilder sqlValue = new StringBuilder("VALUES (");
        // (2) 遍歷 entity 欄位與數值 設定SQL
        for (Map.Entry<String, Object> entity : entityMap.entrySet()) {
            if (entity.getValue() != null) {
                sql.append(entity.getKey()).append(",");
                sqlValue.append(quoteValue(entity.getValue())).append(",");
            }
        }
        // (3) 動態SQL 刪除結尾 ","
        sql.setLength(sql.length()-1);
        sqlValue.setLength(sqlValue.length()-1);
        // (4) 組合結尾
        sql.append(") ").append(sqlValue).append(")");

        // 執行 SQL
        entityManager.createNativeQuery(sql.toString()).executeUpdate();
    }

    /**
     * 根據 JPA 的 @Column(name) 自動生成 UPDATE SQL 並執行
     * @param oldEntityInstance 資料表的 舊實體
     * @param newEntityInstance 資料表的 新實體
     */
    @Transactional
    public void updateEntity(Object oldEntityInstance, Object newEntityInstance) {
        if (!oldEntityInstance.getClass().equals(newEntityInstance.getClass())) {
            throw new RuntimeException("舊實體和新實體必須是相同類型");
        }

        // 取得 tableName
        String entityName = getTableName(oldEntityInstance.getClass());

        // 取得 entity 欄位與數值
        Map<String, Object> oldEntityMap = getEntityNameAndValues(oldEntityInstance);
        Map<String, Object> newEntityMap = getEntityNameAndValues(newEntityInstance);

        // 動態生成 SQL
        // (1) 組合 SET
        StringBuilder sql = new StringBuilder("UPDATE ")
                .append(entityName).append(" SET ");
        for (Map.Entry<String, Object> entity : newEntityMap.entrySet()) {
            sql.append(entity.getKey()).append("=").append(quoteValue(entity.getValue())).append(",");
        }
        sql.setLength(sql.length()-1);

        // (2) 組合 WHERE
        StringBuilder sqlWhere = new StringBuilder("WHERE ");
        for (Map.Entry<String, Object> entity : oldEntityMap.entrySet()) {
            sqlWhere.append(entity.getKey()).append("=").append(quoteValue(entity.getValue())).append(" AND ");
        }
        sqlWhere.setLength(sqlWhere.length()-4);

        // (3) 組合結尾
        sql.append(" ").append(sqlWhere);

        // 執行 SQL
        entityManager.createNativeQuery(sql.toString()).executeUpdate();

    }

    /**
     * 根據 JPA 的 @Column(name) 自動生成 DELETE SQL 並執行
     * @param entityInstance 資料表的 實體
     */
    @Transactional
    public void deleteEntity(Object entityInstance) {
        // 取得 tableName
        String entityName = getTableName(entityInstance.getClass());

        // 取得 entity 欄位與數值
        Map<String, Object> entityMap = getEntityNameAndValues(entityInstance);

        // 動態生成 SQL
        // (1) 組合 SQL
        StringBuilder sql = new StringBuilder("DELETE FROM ")
                .append(entityName).append(" WHERE ");
        for (Map.Entry<String, Object> entity : entityMap.entrySet()) {
            sql.append(entity.getKey()).append("=").append(quoteValue(entity.getValue())).append(" AND ");
        }
        // (2) 動態SQL 刪除結尾 ","
        sql.setLength(sql.length()-4);;

        // 執行 SQL
        entityManager.createNativeQuery(sql.toString()).executeUpdate();
    }

    /**
     * 根據 JPA 的 @Column(name) 獲取 資料表實例 的 欄位及數值
     * @param entity    資料表的 實例
     * @return  Map: key=entityName, value=entityValue
     */
    private Map<String, Object> getEntityNameAndValues(Object entity) {
        Map<String, Object> entityData = new HashMap<>();

        // 取得 entity 實體 所有欄位的 Field
        Field[] fields = entity.getClass().getDeclaredFields();
        for (Field field : fields) {
            // 獲取 columnName
            String columnName = getColumnName(field);
            // 獲取 columnValue
            field.setAccessible(true);
            try {
                Object columnValue = field.get(entity);
                entityData.put(columnName, columnValue);
            } catch (IllegalAccessException e) {
                throw new RuntimeException("Failed to access field value");
            }
        }
        return entityData;
    }


    /**
     * 將 Object 數值 轉換為 String
     */
    private String quoteValue(Object value) {
        if (value instanceof String || value instanceof Character) {
            return "'" + value.toString().replace("'", "''") + "'";
        } else {
            return (value == null) ? "''" : value.toString();
        }
    }

    /**
     * 根據 entity 的 @Table(name) 獲取 tableName
     * @param entityClass   資料表的 類對象
     * @return tableName
     */
    private String getTableName(Class<?> entityClass) {
        // 取得 @Table 的資料
        Table tableAnnotation = entityClass.getAnnotation(Table.class);
        // 有 @Table(name) 才取得 tableName，否則 取得 className
        if (tableAnnotation != null && !tableAnnotation.name().isEmpty()) {
            return tableAnnotation.name();
        } else {
            return entityClass.getName();
        }
    }

    /**
     * 根據 entity 的 @Column(name) 獲取 columnName
     * @param field entity 欄位 透過反射獲取的 Field 物件
     * @return columnName
     */
    private String getColumnName(Field field) {
        // 取得 @Column 的資料
        Column columnAnnotation = field.getAnnotation(Column.class);
        // 有 @Column(name) 才取得 columnName，否則 取得 欄位名稱
        if (columnAnnotation != null) {
            return columnAnnotation.name();
        } else {
            return field.getName();
        }
    }
}



